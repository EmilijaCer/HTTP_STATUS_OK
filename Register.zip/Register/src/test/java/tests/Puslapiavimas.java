package tests;

import org.junit.jupiter.api.Test;
import pageobjects.LoginPage;
import pageobjects.MainPage;
import pageobjects.ProjectPage;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Puslapiavimas extends BaseTestLogin {
    MainPage mainPage;
    LoginPage loginPage;
    ProjectPage projectPage;
    @Test
    void psl(){
        loginPage.inputUsernameL("admin");
        loginPage.inpuPasswordL("admin");
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        loginPage.clicL();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        projectPage.createProject();
        Random randomGeneratorPN = new Random();
        String projectName = randomGeneratorPN.nextInt(1000) + "projektas";
        ProjectPage.inputProjectName(projectName);
        Random randomGeneratorPD = new Random();
        String projectDescription = randomGeneratorPD.nextInt(1000) + "projektas";
        ProjectPage.inputProjectDescription(projectName);
        ProjectPage.clickSave();
    }
}
