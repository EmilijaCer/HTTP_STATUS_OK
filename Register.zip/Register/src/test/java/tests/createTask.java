package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import pageobjects.LoginPage;
import pageobjects.MainPage;
import pageobjects.ProjectPage;
import pageobjects.TaskPage;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static pageobjects.TaskPage.*;

public class createTask extends BaseTestLogin {
    MainPage mainPage;
    LoginPage loginPage;
    ProjectPage projectPage;
    TaskPage taskPage;
    @Test
    void createTask() {

        mainPage = new MainPage(driver);
        loginPage = new LoginPage(driver);
        projectPage = new ProjectPage(driver);
        taskPage = new TaskPage(driver);

        loginPage.inputUsernameL("admin");
        loginPage.inpuPasswordL("admin");
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        loginPage.clicL();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        projectPage.createProject();
        Random randomGeneratorPN = new Random();
        String projectName = randomGeneratorPN.nextInt(1000) + "projektas";
        ProjectPage.inputProjectName(projectName);
        Random randomGeneratorPD = new Random();
        String projectDescription = randomGeneratorPD.nextInt(1000) + "description";
        ProjectPage.inputProjectDescription(projectDescription);
        ProjectPage.clickSave();

        TaskPage.clickCreateTask();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        TaskPage.clickNewTask();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        Random randomGenerator = new Random();
        String taskName = randomGenerator.nextInt(1000) + "task";
        TaskPage.inputTaskName(taskName);
        Random randomGeneratorD = new Random();
        String taskDescription = randomGeneratorD.nextInt(1000) + "description";
        TaskPage.inputTaskDescription(taskDescription);
        TaskPage.saveTask();

    }

}
