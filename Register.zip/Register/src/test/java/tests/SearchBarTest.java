package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import pageobjects.LoginPage;
import pageobjects.MainPage;
import pageobjects.ProjectPage;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SearchBarTest extends BaseTestLogin {
        MainPage mainPage;
        LoginPage loginPage;
        ProjectPage projectPage;

        @Test
        void createProject1() {
            //add new projects to the system, insert essential information such as project name, description, start date, status:TO DO, IN PROGRESS” or “DONE
            mainPage = new MainPage(driver);
            loginPage = new LoginPage(driver);
            projectPage = new ProjectPage(driver);
            loginPage.inputUsernameL("admin");
            loginPage.inpuPasswordL("admin");
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            loginPage.clicL();
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            projectPage.createProject();
            Random randomGeneratorPN = new Random();
            String projectName = randomGeneratorPN.nextInt(1000) + "projektas";
            ProjectPage.inputProjectName(projectName);
            Random randomGeneratorPD = new Random();
            String projectDescription = randomGeneratorPD.nextInt(1000) + "description";
            ProjectPage.inputProjectDescription(projectDescription);
            ProjectPage.clickSave();

            projectPage.createProject();
            Random randomGeneratorPN2 = new Random();
            String projectName2 = randomGeneratorPN2.nextInt(1000) + "projektas";
            ProjectPage.inputProjectName(projectName2);
            Random randomGeneratorPD2 = new Random();
            String projectDescription2 = randomGeneratorPD2.nextInt(1000) + "description";
            ProjectPage.inputProjectDescription(projectDescription2);
            ProjectPage.clickSave();

            //keiciu statusa
            projectPage.editProject();
            ProjectPage.clearPrName();
            Random randomGeneratorPN3 = new Random();
            String projectName3 = randomGeneratorPN3.nextInt(1000) + "projektas";
            ProjectPage.inputProjectName(projectName3);
            ProjectPage.clearPrDescription();
            Random randomGeneratorPD3 = new Random();
            String projectDescription3 = randomGeneratorPD3.nextInt(1000) + "description";
            ProjectPage.inputProjectDescription(projectDescription3);
            ProjectPage.projectStatus("DONE");
            ProjectPage.clickEdit();
            ProjectPage.saveEdit();
//            String expectedMessage3 = projectName2;
//            String actualMessage3 = projectName2;
//            assertEquals(expectedMessage, actualMessage, "Project do not created");

        }
    @Test
    void searchProjectName() {
        //add new projects to the system, insert essential information such as project name, description, start date, status:TO DO, IN PROGRESS” or “DONE
        mainPage = new MainPage(driver);
        loginPage = new LoginPage(driver);
        projectPage = new ProjectPage(driver);

        loginPage.inputUsernameL("admin");
        loginPage.inpuPasswordL("admin");
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        loginPage.clicL();
        ProjectPage.setSearchPrName("752projektas");
    }
    @Test
    void filterStatus() {
        //add new projects to the system, insert essential information such as project name, description, start date, status:TO DO, IN PROGRESS” or “DONE
        mainPage = new MainPage(driver);
        loginPage = new LoginPage(driver);
        projectPage = new ProjectPage(driver);

        loginPage.inputUsernameL("admin");
        loginPage.inpuPasswordL("admin");
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        loginPage.clicL();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            ProjectPage.projectStatusFilter("TO DO");
        }
}
