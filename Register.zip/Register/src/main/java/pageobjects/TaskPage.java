package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class TaskPage extends BasePage {
    public TaskPage(WebDriver driver) {
        super(driver);
    }
    @FindBy (css = "div[class='project-cards-container'] div:nth-child(1) div:nth-child(1) a:nth-child(1) div:nth-child(1) p:nth-child(1)")
    private static WebElement createTask;
    @FindBy (css = ".btn.btn-toggle.d-inline-flex.align-items-center.rounded.border-0.collapsed[data-bs-toggle='collapse'][data-bs-target='#dashboard-collapse']")
    private static WebElement newTask;

    @FindBy (css = "#taskTitle")
    private static WebElement taskName;
    @FindBy (css = "#taskDescription")
    private static WebElement taskDescription;
    @FindBy (css = "setTask")
    private static WebElement taskStatus;
    @FindBy (css= "button[type='submit']")
    private static WebElement setSave;

    public static void clickCreateTask() {
        createTask.click();}
    public static void clickNewTask() {
        newTask.click();}
    public static void inputTaskName(String name) {
        taskName.click();}
    public static void inputTaskDescription(String name) {
        taskDescription.click();}
    public static void setTaskStatus(String ToDo) {
        Select dropdown = new Select(taskStatus);
        dropdown.selectByVisibleText(ToDo);}

    public static void saveTask () {
        setSave.click();
        }
    }
